import sqlalchemy

metadata = sqlalchemy.MetaData()

# 抽奖表
giveaways = sqlalchemy.Table(
    'giveaway',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.String, primary_key=True),
    sqlalchemy.Column('code', sqlalchemy.String),
    sqlalchemy.Column('start_time', sqlalchemy.DateTime),
    sqlalchemy.Column('end_time', sqlalchemy.DateTime),
    sqlalchemy.Column('minutes', sqlalchemy.Integer),
    sqlalchemy.Column('winners', sqlalchemy.Integer),
    sqlalchemy.Column('activate', sqlalchemy.Boolean, default=True),
)

# 定时恢复名字表
nick_temp = sqlalchemy.Table(
    'nick_temp',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.String),
    sqlalchemy.Column('name', sqlalchemy.String),
    sqlalchemy.Column('change_time', sqlalchemy.DateTime),
)

# 人员积分详情
user_score = sqlalchemy.Table(
    'user_score',
    metadata,
    # 递增id
    sqlalchemy.Column('id', sqlalchemy.Integer, primary_key=True, autoincrement=True),
    sqlalchemy.Column('user_id', sqlalchemy.String),
    # 获得积分
    sqlalchemy.Column('score', sqlalchemy.Integer, default=0),
    # 积分类型 目前为 text image
    sqlalchemy.Column('score_type', sqlalchemy.String),
    sqlalchemy.Column('create_time', sqlalchemy.DateTime, default=sqlalchemy.func.now()),
)

# 成员信息表，包括用户积分和生日
user_info = sqlalchemy.Table(
    'user_info',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.String, primary_key=True),
    # 名片文件名，默认为 id.jpg
    sqlalchemy.Column('card', sqlalchemy.String, default=''),
    # 生日
    sqlalchemy.Column('birthday_month', sqlalchemy.Integer),
    sqlalchemy.Column('birthday_day', sqlalchemy.Integer),
    # 总积分
    sqlalchemy.Column('total_score', sqlalchemy.Float, default=0.0),
    # 心动值(礼物赠送值)
    sqlalchemy.Column('gift_score', sqlalchemy.Float, default=0.0),
    sqlalchemy.Column('create_time', sqlalchemy.DateTime, default=sqlalchemy.func.now()),
    sqlalchemy.Column('update_time', sqlalchemy.DateTime, default=sqlalchemy.func.now(),
                      onupdate=sqlalchemy.func.now()),
)

# 积分兑换项表
score_exchange = sqlalchemy.Table(
    'score_exchange',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.Integer, primary_key=True, autoincrement=True),
    sqlalchemy.Column('name', sqlalchemy.String),
    sqlalchemy.Column('details', sqlalchemy.String),
    sqlalchemy.Column('score', sqlalchemy.Float),
    sqlalchemy.Column('stock', sqlalchemy.Integer),
    sqlalchemy.Column('is_activate', sqlalchemy.Boolean, default=True),
    sqlalchemy.Column('create_time', sqlalchemy.DateTime, default=sqlalchemy.func.now()),
    sqlalchemy.Column('update_time', sqlalchemy.DateTime, default=sqlalchemy.func.now(),
                      onupdate=sqlalchemy.func.now())
)

# 积分兑换记录
score_exchange_record = sqlalchemy.Table(
    'score_exchange_record',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.Integer, primary_key=True, autoincrement=True),
    # 兑换用户的id
    sqlalchemy.Column('user_id', sqlalchemy.String),
    # 兑换值为 score_exchange 的主键id
    sqlalchemy.Column('exchange_id', sqlalchemy.Integer),
    sqlalchemy.Column('score', sqlalchemy.Float),
    sqlalchemy.Column('create_time', sqlalchemy.DateTime, default=sqlalchemy.func.now())
)

# 彩蛋幸运成员记录
egg_lucky_record = sqlalchemy.Table(
    'egg_lucky_record_230520',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.Integer, primary_key=True, autoincrement=True),
    # 成员id
    sqlalchemy.Column('user_id', sqlalchemy.String),
    sqlalchemy.Column('user_name', sqlalchemy.String),
    sqlalchemy.Column('message_id', sqlalchemy.String),
    sqlalchemy.Column('message_channel_id', sqlalchemy.String),
    sqlalchemy.Column('message_channel_name', sqlalchemy.String),
    sqlalchemy.Column('message_guild_id', sqlalchemy.String),
    # 彩蛋内容
    sqlalchemy.Column('details', sqlalchemy.String),
    sqlalchemy.Column('create_time', sqlalchemy.DateTime, default=sqlalchemy.func.now()),
)

# 礼物赠送记录
gift_record = sqlalchemy.Table(
    'gift_record',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.Integer, primary_key=True, autoincrement=True),
    # 赠送人id
    sqlalchemy.Column('giver_id', sqlalchemy.String),
    # 接收人id
    sqlalchemy.Column('receiver_id', sqlalchemy.String),
    # 礼物内容
    sqlalchemy.Column('details', sqlalchemy.String),
    # 礼物价格
    sqlalchemy.Column('price', sqlalchemy.Float),
    sqlalchemy.Column('create_time', sqlalchemy.DateTime, default=sqlalchemy.func.now()),
)

# 下单记录 根据 user_roll_map为表格字段
# user_roll_map[user_id] = {
#     'job_id': job_id,
#     'roll_id': roll_id,
#     'text': 下单需求,
#     'ref_msg_id': message.id,
#     'command': str(自定义扣单口令),
#     'user': interaction.user,
#     'end_time': end_time,
#     'pp_private_message': {},
#     'pp_private_message_pp_id_map': {},
#     'pp_id_pp_private_message_map': {},
#     'pp_channel_messages_id_list': {},
#     'pp_id_channel_message_pp_id_map': {},
#     'pp_channel_message_id_pp_id_map': {},
#     'anonymous': 是否匿名
# }
orders = sqlalchemy.Table(
    'orders',
    metadata,
    sqlalchemy.Column('id', sqlalchemy.Integer, primary_key=True, autoincrement=True),
    sqlalchemy.Column('user_id', sqlalchemy.String),
    sqlalchemy.Column('job_id', sqlalchemy.Integer),
    sqlalchemy.Column('roll_id', sqlalchemy.Integer),
    sqlalchemy.Column('text', sqlalchemy.String),
    sqlalchemy.Column('ref_msg_id', sqlalchemy.String),
    sqlalchemy.Column('command', sqlalchemy.String),
    sqlalchemy.Column('end_time', sqlalchemy.DateTime),
    sqlalchemy.Column('anonymous', sqlalchemy.Boolean),
    sqlalchemy.Column('create_time', sqlalchemy.DateTime, default=sqlalchemy.func.now()),
    sqlalchemy.Column('update_time', sqlalchemy.DateTime, default=sqlalchemy.func.now(),
                      onupdate=sqlalchemy.func.now())
)
