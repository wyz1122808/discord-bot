# Discord机器人

## 机器人功能

### 后台逻辑

- 数据存储
- 后台任务（发消息）
- 文字接入
- 菜单功能

### 自动化下单流程

- [ ] 陪玩扣单之后，机器人私信发给老板名片信息
- [ ] 老板可以通过私发的名片 点击点单或匿名点单 选择陪玩，同时在公屏上会显示：xx老板已经点单xx陪玩+自定义内容(所有点单内容 例如libra时间点coco会记录在log里） （盲盒点单）
- [ ] 冠名自动改回原名（比如，libra的七天小猫咪，七天之后机器人自动去掉后缀）（需要公会配合统一冠名后缀格式）

### 积分系统

数值可以商议调整

- [ ] 发消息/图片视频积分(按照个数）
- [ ] 语音/streaming 积分（按照分钟数）
- [ ] 陪玩/老板积分查询口令(例如： /rank, 同时需要公会确定积分如何兑换其他奖励，可以在机器人指令中查询）

积分表：
人id 消息id 消息类型 积分数值

总积分表：
人id 总积分 更新时间

积分系统更新：

1. 老板下单点单的陪玩+1
2. 老板下单+1
3. 陪玩跟着老板下单扣命令的+0.1

积分兑换功能

1. 新增一条积分兑换明细
2. 根据id编辑积分兑换明细
3. 删除一条积分兑换
4. 删除所有积分兑换项

### 抽奖 

- [ ] 自定义抽奖口令 自动抽奖
- [ ] 可以同时发起多个抽奖 最终可以@抽奖用户
- [ ] 终止某个抽奖 清空抽奖功能 方便管理
- [ ] 如果有某人参加抽奖，可能有几率会触发一个彩蛋（例：libra是小仙女）

抽奖表：
- 抽奖时间
- 抽奖口令
- 抽奖人数
- 中奖人id列表
- 是否激活抽奖
- 特殊中奖名单

### 生日

1. 使用指令`/setbirthday`设置生日
2. 使用指令`/birthday`查看生日
3. 使用指令`/birthdaylist`查看生日列表
4. 生日当天发送生日祝福

### 名片

使用指令`!card [用户id]`设置名片图片


### 彩蛋功能

1. 成员发言的时候随机发生彩蛋
2. 频率一周一次
3. 中奖后，在公屏机器人显示该成员中奖，并将成员改名
4. 下一周的周一0点将名字恢复

## 设置

1. 创建机器人
   - https://discord.com/developers/applications -> new applications
   - 在频道-设置-身份组-点击机器人-编辑身份组-权限设置-打开所需要的权限
   - 频道设置-管理-安全设置-最底部-打开双重认证要求
2. 打开开发者模式 Settings > Advanced and enable developer mode.
3. 获取 guild:  右键频道复制ID
4. 获取身份组ID： 右键身份组复制ID

## 部署

```bash
sudo apt install -y wget git tmux
# 下载minidocnda
wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh
# 安装miniconda
bash ./Miniconda3-latest-Linux-x86_64.sh

# 按下 enter
# 翻页到最下面
# 按下 yes
# 回车默认安装就可以

# 初始化conda
./miniconda3/bin/conda init
#重启终端

# 创建conda环境
conda create -n discord

# 开启一个tmux
tmux new -s discord
git clone https://github.com/yololccg/dsbot
cd ./dsbot

# 安装依赖
pip install -r ./requirements.txt

# 修改环境变量
cp example.env .env
vim .env
# vim 之后按 i 进入编辑，按 esc，:x或者:wq修改
# 填入上面的设置
```

以后的运行

```bash
# 进入终端
tmux a -t discord
python main.py
```
