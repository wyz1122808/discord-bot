gift_responses = {
    'default': """:1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: :1025149108077465610: 

 :962887121998315631:  :962887121998315631: 感谢  :804201856988348436:  帅气可爱大方 :804201962614292482:  的 {from_user} 送给 {to_user} 的 {gift_name} x {gift_count}！

 :1_17:感谢老板 :712524119983259681:
 :712524119983259681: 心动值 +{score} 点:budinggou:""",
    'special': """ 感谢 * 帅气可爱大方 * 的 {from_user} 老板送给 {to_user}  的

\t\t\t   *   {gift_name} x {gift_count}  * 

\t\t\t\t\t\t\t\t\t\t\t\t\t   * 谢谢老板！* 老板大气~

\t\t* 心动值+ {score}点
\t"""
}

rename_responses = {
    '半日冠': """
:851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: :851001082356170792: 

 :C2_RainbowHeart:  :pinkenvelope: 感谢  :804201856988348436:  帅气可爱大方 :804201962614292482:  的 {from_user} 送给 {to_user} 的半日冠名！

:1_17: 感谢老板 :712524119983259681:
:712524119983259681: 心动值+66点 :chu:""",
    # \t '周冠': """
    # :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02: :y_star02:
    #
    # :8_123213: :8_123213:   感谢  :blwing: :hfk: 帅气可爱大方 :hfk:  :brwing:  的 {from_user}
    # \t\t\t  送给 {to_user} 的
    #
    #
    # \t\t\t\t\t   :tlwHeart_Pink:  :868365808936570900: 炙热香炉\t一周冠名  ！:868365808936570900:  :tlwHeart_Pink:
    #
    # \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t :712524119983259681: 感谢老板！:hyheart: 老板大气~
    # :853947868553543700: 心动值+888点:p_heart33:  :8_123213: :8_123213:""",
    '三日冠': """
:hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: :hy_petals: 

:4328heartpinkpuff: :4328heartpinkpuff:  感谢  :blwing: :hfk: 帅气可爱大方 :hfk:  :brwing:  的 {from_user}
\t\t\t送给 {to_user} 的

\t\t\t\t\t\t\t  :hyheart:  骑士之誓  三日冠！:hyheart:

\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t:712524119983259681:  感谢老板！:1_17:老板大气~
:853947868553543700: 心动值+365点  :brownstar:   :4328heartpinkpuff: :4328heartpinkpuff:""",
    '日冠': """:little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: :little_twin_stars_star: 

:zzcafe_coffeecupcute2:  :zzcafe_coffeecupcute2: 感谢  :804201856988348436:  帅气可爱大方 :804201962614292482: 的 {from_user} 送给 {to_user} 的一日冠名！

:1_17: 感谢老板 :712524119983259681:
:VS_sparkly: 心动值+131.4点""",
    '五日冠': """
:deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01::deco_flower01:

 :p_kfloat: :p_kfloat:  感谢  :blwing: :hfk: 帅气可爱大方 :hfk:  :brwing:  的 {from_user}
\t\t\t送给 {to_user} 的


\t\t\t\t\t\t\t\t :cbxs:\t救赎 五日冠名！ :cbxs: 

\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t :712524119983259681: 感谢老板！:hyheart: 老板大气~

:853947868553543700: 心动值+521点:771539740657844225:  :p_kfloat: :p_kfloat:"""

}


welcome_text = """
哈咯～欢迎 {name} 加入优可电竞！！
让我们从 #导航目录 开始了解服务器叭！！
新加入的老板一定要熟读#下单须知 哦！优可谢谢老板的配合～
入职/充值/下单 或者任何疑问随时来找我们 @在线客服 叭！24小时为老板答疑解惑～ 
"""

welcome_pp_text = """
哈咯～你终于来啦！！

入职的话可以先看一下 #加入我们 确认标准 然后填写好表格发给@在线客服 哦～
下单/充值或者有任何建议请随时联系我们 @在线客服 ～ 希望能给您带来最好的游戏体验哦！

优可有很多幽默可爱的小哥哥小姐姐！随时来找我们玩叭～"""


gifts_text = """

喵子冰淇淋 $33

兔几便当盒 $66
 
:1013188921141755926:  sb14k   :101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756:     $6.6

气噗噗的老头 $7.88

:o_aflower01:  印花集         :101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756:     $6.6

:g_aflower5:  要抱抱         :101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756:     $13.14

:food_differentcake:  生日蛋糕  :101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756:    $33.44

:b_gun2:  枪响人亡     :101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756:     $28.8

:c_flowersblue:  水栽竹          :101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756:     $52

:key:  神秘钥匙     :101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756:     $52

:r_flower2:  美杜莎          :101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756:     $88

:catbox:  神秘宝箱     :101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756:     $99

:pr_flower3:  波塞冬         :101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756::101ccf27867939b54e5b1806cc588756:     $128
"""


order_custom_boss_info = {
    '354813246294982656': {
        'name': 'Eroderrrr#6240',
        'id': '354813246294982656',
        'url': 'https://media.discordapp.net/attachments/1040080636830040084/1073855722909077565/3.png'
    },
    '535256308987854858': {
        'name': 'Kev#5634',
        'id': '535256308987854858',
        'url': 'https://media.discordapp.net/attachments/1040080636830040084/1073855825648549929/1.png'
    },
    '333760585013395456': {
        'name': 'LittleFeiLove#0704',
        'id': '333760585013395456',
        'url': 'https://media.discordapp.net/attachments/1040080636830040084/1073855913007534100/2.png'
    },
    '422994555923726338': {
        'name': 'paperbond#1270',
        'id': '422994555923726338',
        'url': 'https://media.discordapp.net/attachments/1040080636830040084/1073856051608297482/unknown.png'
    },
    '726553506605170699': {
        'name': 'WUWU#1002',
        'id': '726553506605170699',
        'url': 'https://media.discordapp.net/attachments/1040080636830040084/1073856170487447612/wuwu.png'
    },
    '382600787475562506': {
        'name': 'qisen#9999',
        'id': '382600787475562506',
        'url': 'https://media.discordapp.net/attachments/1040080636830040084/1073856242314907678/qisen.png'
    },
    '428451817635053569': {
        'name': 'TDBankCanada#4782',
        'id': '428451817635053569',
        'url': 'https://media.discordapp.net/attachments/918755269620666418/990763698421399613/Sky_Illustration_Good_Night_Zoom_Virtual_Background_1063_336__1.gif'
    },
    '636028857614598172': {
        'name': 'Yang#6472',
        'id': '636028857614598172',
        'url': 'https://media.discordapp.net/attachments/979167848557596683/979536115927224390/1063_336_.gif'
    },
    '671771279329853450': {
        'name': 'Peppa#0224',
        'id': '671771279329853450',
        'url': 'https://media.discordapp.net/attachments/1040080636830040084/1073856579557937182/jjnh.png'
    },
    '309923506819301376': {
        'name': '浮生#2454',
        'id': '309923506819301376',
        'url': 'https://media.discordapp.net/attachments/918755269620666418/998325870714441860/Peach_Playful_School_Daily_Vlog_Opening_Video_1063_336__2.gif'
    },
    '450402046374313994': {
        'name': '媛媛SuKi酱#0309',
        'id': '450402046374313994',
        'url': 'https://media.discordapp.net/attachments/918755269620666418/1011002524070858772/Sky_Illustration_Good_Night_Zoom_Virtual_Background_1063_336__1.gif'
    },
    '882786812379168799': {
        'name': '布洛芬胶囊#6666',
        'id': '882786812379168799',
        'url': 'https://media.discordapp.net/attachments/949062697620733992/1068714214501388378/093a8e6c436e2db8.gif'
    },

    '617595835122974730': {
        'name': 'sakuraaa#7777',
        'id': '617595835122974730',
        'url': 'https://media.discordapp.net/attachments/1040080636830040084/1087601416257941504/sakura.png?width=1920&height=649'
    },
    '625187840837287937': {
        'name': 'joyx33#3333',
        'id': '625187840837287937',
        'url': 'https://cdn.discordapp.com/attachments/1069533217402650664/1089082752931995748/33.png'
    },
    '308751100209528833': {
        'name': 'Fishy.#0816',
        'id': '308751100209528833',
        'url': 'https://cdn.discordapp.com/attachments/1069533217402650664/1089082942367744010/a3a265ca4cf89710.png'
    }
}
