from loguru import logger
from pydantic import BaseSettings


class _Settings(BaseSettings):
    TOKEN: str = ''
    GUILD: int = ''
    TIMEZONE: str = 'Asia/Shanghai'
    DEBUG: bool = False
    DATABASE: str = 'sqlite+aiosqlite:///database.db'
    # 管理员频道 ID
    ADMIN_CHANNEL_ID: int = 1026003196050673751
    # 生日祝福频道 ID
    BIRTHDAY_CHANNEL_ID: int = 1026003196050673751
    # 聊天频道 ID
    CHAT_CHANNEL_ID: int = 1026003196050673751
    # 商店频道 ID
    SHOP_CHANNEL_ID: int = 1026003196050673751
    # 下单频道 ID
    ORDER_CHANNEL_ID: int = 1026003196050673751
    # 抽奖频道 ID
    ROLL_CHANNEL_ID: int = 1026003196050673751
    # 播报频道 ID
    BROADCAST_CHANNEL_ID: int = 1026003196050673751
    # 打赏频道 ID
    GIFT_CHANNEL_ID: int = 1026003196050673751
    # 试音频道 ID
    VOICE_TEST_CHANNEL_ID: int = 1026003196050673751

    # 通知
    # 默认通知频道ID
    DEFAULT_NOTIFY_CHANNEL_ID: int = 1026003196050673751
    # 下单通知频道ID
    ORDER_NOTIFY_CHANNEL_ID: int = 1066082861184192542
    # 抽奖通知频道ID
    ROLL_NOTIFY_CHANNEL_ID: int = 1083995693498249266
    # 打赏通知频道ID
    GIFT_NOTIFY_CHANNEL_ID: int = 1083995728675868813

    # 设置最大的抽奖分钟数
    GIVEAWAY_MAX_MINUTES: int = 60

    # 客服组ID
    CUSTOMER_SERVICE_ROLE_ID: int = 1028620972695228496

    # 游戏
    GAME_NOTIFY_CHANNEL_ID: int = 1106511999791280218

    class Config:
        # 使用环境变量读取
        env_file = ".env"


SETTINGS = _Settings()
print(f'loguru level: {SETTINGS.DEBUG}, settings: {SETTINGS}')
