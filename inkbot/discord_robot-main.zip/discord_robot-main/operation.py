"""运维脚本"""

import asyncio
from datetime import datetime

import databases
from sqlalchemy.ext.asyncio import create_async_engine

from models import user_score
from settings import SETTINGS

# 数据库设置
database = databases.Database(SETTINGS.DATABASE)
engine = create_async_engine(
    SETTINGS.DATABASE, echo=True
)


# 打开birthdays.txt
async def set_birthdays():
    with open('data/birthdays.txt', 'r') as f:
        birthdays = f.read().splitlines()
    for birthday in birthdays:
        user_id, utc_birthday = birthday.split(',')
        # 将UTC时间转换为月日
        user_id = user_id.strip()
        utc_birthday = utc_birthday.strip()
        birthday_month, birthday_day = datetime.fromtimestamp(int(utc_birthday)).strftime('%m-%d').split('-')
        print(user_id, birthday_month, birthday_day)
        # 写入数据库的user_info表
        await database.execute(
            'INSERT INTO user_info (id, birthday_month, birthday_day) VALUES (:id, :birthday_month, :birthday_day)',
            values={'id': user_id, 'birthday_month': birthday_month, 'birthday_day': birthday_day}
        )


def test():
    test_code = ''
    # 检查test_code的unicode编码是多少
    for i in test_code:
        print(ord(i))


async def clear_scores():
    """清空用户的所有积分"""
    query = user_score.select()
    results = await database.fetch_all(query)
    for result in results:
        print(result['user_id'], result['total_score'])
        # await database.execute(
        #     'UPDATE user_info SET total_score=0 WHERE id=:id',
        #     values={'id': result['user_id']}
        # )


if __name__ == '__main__':
    asyncio.run(clear_scores())
