from enum import Enum


class _Consts():
    # 寿星前缀或后缀
    BIRTHDAY_NAME = '今日寿星'


class VoiceTestType(str, Enum):
    """试音类型"""
    不用试音 = '不用试音'
    可能试音 = '可能试音'
    需要试音 = '需要试音'


class AnonymousType(str, Enum):
    """是否匿名"""
    我要匿名 = '我要匿名'
    不要匿名 = '不要匿名'


class NamedType(str, Enum):
    """日冠类型"""
    半日冠 = '半日冠'
    日冠 = '日冠'
    三日冠 = '三日冠'
    五日冠 = '五日冠'
    # 周冠 = '周冠'


class GiftName(str, Enum):
    喵子冰淇淋 = '喵子冰淇淋'
    兔几便当盒 = '兔几便当盒'
    气噗噗的老头 = '气噗噗的老头'
    sb14k = 'sb14k'
    印花集 = '印花集'
    要抱抱 = '要抱抱'
    生日蛋糕 = '生日蛋糕'
    枪响人亡 = '枪响人亡'
    水栽竹 = '水栽竹'
    神秘钥匙 = '神秘钥匙'
    美杜莎 = '美杜莎'
    神秘宝箱 = '神秘宝箱'
    波塞冬 = '波塞冬'


CONSTS = _Consts()
