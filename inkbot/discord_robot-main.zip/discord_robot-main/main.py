import asyncio
import functools
import json
import logging
import os
import random
import re
import time
import uuid
from datetime import datetime, timedelta
from logging.handlers import RotatingFileHandler
from typing import Optional

import databases
import discord
import pytz
from apscheduler.jobstores.base import JobLookupError
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.date import DateTrigger
from discord import app_commands, Member
from loguru import logger
from sqlalchemy.ext.asyncio import create_async_engine

from consts import CONSTS, VoiceTestType, AnonymousType, NamedType, GiftName
from data.custom_response import rename_responses, gift_responses, gifts_text, order_custom_boss_info
from models import giveaways, metadata, user_score, user_info, score_exchange, egg_lucky_record, gift_record
from settings import SETTINGS

# 本体设置，服务器ID
MY_GUILD = discord.Object(id=SETTINGS.GUILD)

# 数据库设置
database = databases.Database(SETTINGS.DATABASE)
engine = create_async_engine(
    SETTINGS.DATABASE, echo=True
)

# 定时器
jobstores = {
    'default': SQLAlchemyJobStore(url='sqlite:///scheduler.db')
}
executors = {
    # 'default': ThreadPoolExecutor(20),
    # 'processpool': ProcessPoolExecutor(5)
}
job_defaults = {
    'coalesce': True,
    'max_instances': 100
}

# 记录老板和消息响应
try:
    with open("data/user_roll_map.json", "r", encoding="utf-8") as f:
        try:
            user_roll_map = json.load(f)
        except json.decoder.JSONDecodeError:
            user_roll_map = {}
            logger.info('user_roll_map.json is empty')
except FileNotFoundError:
    user_roll_map = {}
    with open("data/user_roll_map.json", "w", encoding="utf-8") as f:
        json.dump(user_roll_map, f, ensure_ascii=False, indent=4)
    logger.info('user_roll_map.json is not exist')
# 陪玩的基本信息
pp_share_info = {}

# emojis
emojis = None

# 当不存在的时候，创建images和logs文件夹
if not os.path.exists('images'):
    os.mkdir('images')
if not os.path.exists('logs'):
    os.mkdir('logs')


async def save_card_info(image_name, image_content):
    """保存图片"""
    with open(image_name, 'wb') as f:
        f.write(image_content)
        logger.info(f'save image {image_name} success')


def save_roll_map():
    pass


LUCKY_EGG_FLAG = False
game_start_channels = {}


async def check_lucky_egg():
    """从数据库中查询"""
    # 根据彩蛋的创建时间倒序，选择最后一个
    global LUCKY_EGG_FLAG
    query = egg_lucky_record.select().order_by(egg_lucky_record.c.create_time.desc())
    result = await database.fetch_one(query)
    if result != -1:
        try:
            last_egg_time = result['create_time']
            # 赋予时区
            last_egg_time = last_egg_time.replace(tzinfo=pytz.timezone(SETTINGS.TIMEZONE))
        except Exception:
            logger.warning(f'egg_lucky_record is empty: {result}')
            last_egg_time = datetime.now(pytz.timezone(SETTINGS.TIMEZONE)) - timedelta(days=8)
    else:
        last_egg_time = datetime.now(pytz.timezone(SETTINGS.TIMEZONE)) - timedelta(days=8)
    last_monday = datetime.now(pytz.timezone(SETTINGS.TIMEZONE)) - timedelta(
        days=datetime.now(pytz.timezone(SETTINGS.TIMEZONE)).weekday())

    if last_egg_time < last_monday or \
            last_egg_time < datetime.now(pytz.timezone(SETTINGS.TIMEZONE)) - timedelta(days=7):
        LUCKY_EGG_FLAG = True
        logger.info(f'reset LUCKY_EGG_FLAG to {LUCKY_EGG_FLAG}')


class MyClient(discord.Client):
    def __init__(self, *, intents: discord.Intents):
        super().__init__(intents=intents)
        self.scheduler = None
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        self.tree.copy_global_to(guild=MY_GUILD)
        await self.tree.sync(guild=MY_GUILD)

    async def on_ready(self):
        """初始化的一些操作"""
        # 初始化定时器
        self.scheduler = AsyncIOScheduler(
            jobstores=jobstores, executors=executors, job_defaults=job_defaults,
            timezone=pytz.timezone(SETTINGS.TIMEZONE),
            # event_loop=asyncio.new_event_loop()
        )
        # 增加 check_pp_message_reactions 每5s的定时任务
        # self.scheduler.add_job(check_pp_message_reactions, 'interval', seconds=10)
        # 生日祝福定时器
        # self.scheduler.add_job(check_birthday, 'cron', hour=0, minute=0, second=0)
        # self.scheduler.add_job(recover_birthday_name, 'cron', hour=0, minute=0, second=0)
        self.scheduler.add_job(check_lucky_egg, 'cron', hour=0, minute=0, second=0,
                               next_run_time=datetime.now(tz=pytz.timezone(SETTINGS.TIMEZONE)) + timedelta(seconds=10))
        self.scheduler.start()
        logger.info('Logged on as', self.user)

    async def on_message(self, message: discord.Message):
        """接收消息的函数"""
        global LUCKY_EGG_FLAG
        # logger.debug(f'message.channel {message.channel.id}: {message.channel} message.content: {message.content}')
        if message.author == self.user:
            return
        # 如果消息为机器人的话，不处理
        if message.author.bot:
            return

        # 彩蛋逻辑
        if message.channel.id == SETTINGS.CHAT_CHANNEL_ID and LUCKY_EGG_FLAG:
            # 忽略一些消息
            if '欢迎' in message.content:
                return
            random_num = random.randint(1, 10)
            logger.info(f'lucky egg random_num: {random_num}')
            if random_num > 1:
                # 给彩蛋成员增加后缀
                logger.info(f'check lucky egg with {random_num}')
                try:
                    await message.author.edit(nick=f'{message.author.name}🥚彩蛋幸运者')
                    logger.info(f'修改昵称成功: {message.author.name}🥚彩蛋幸运者')
                except Exception as e:
                    # 如果发生异常，那么把彩蛋视作失败
                    logger.error(f'修改昵称失败: {e}')

                # 提及用户，表示触发彩蛋
                logger.info(f'{message.author.mention} {random_num} 触发彩蛋了！lucky_egg!')
                await message.channel.send(f'{message.author.mention} 触发彩蛋了！')
                await database.execute(egg_lucky_record.insert().values(
                    create_time=datetime.now(pytz.timezone(SETTINGS.TIMEZONE)),
                    user_id=message.author.id,
                    user_name=message.author.name,
                    message_id=message.id,
                    message_channel_id=message.channel.id,
                    message_channel_name=message.channel.name,
                    message_guild_id=message.guild.id,
                ))
                # 添加定时器，在下一个周一的0点0分0秒，恢复彩蛋成员的昵称
                self.scheduler.add_job(
                    recover_old_name, 'date',
                    run_date=datetime.now(pytz.timezone(SETTINGS.TIMEZONE)) + timedelta(days=7),
                    args=[message.channel.id, message.author.id, message.author.name]
                )
                LUCKY_EGG_FLAG = False

        # 如果当前信息在管理员channel中
        if message.channel.id == SETTINGS.ADMIN_CHANNEL_ID:
            message_content = message.content
            # 当消息开头为 !card 时候，保存发来的信息中包含的图片
            if message_content.startswith('!card'):
                # 用户ID 为 !card xxxxx
                try:
                    card_user_id = message_content.split(' ')[1].strip()
                except IndexError:
                    await message.channel.send(f'格式错误: {message_content}, 正确的格式: !card 用户ID [图片]')
                    logger.error(f'格式错误: {message_content}')
                    return
                try:
                    # 检测是否为int类型，不是的话代表有问题，在频道发送错误信息
                    card_user_id = int(card_user_id)
                except ValueError:
                    await message.channel.send(f'错误的用户ID: {card_user_id}')
                    logger.error(f'错误的用户ID: {card_user_id}')
                    return
                # 保存信息的图片
                image_name_path = f'./images/{card_user_id}.png'
                # 保存图片
                try:
                    await save_card_info(image_name_path, await message.attachments[0].read())
                    info = f'保存图片 {image_name_path} 成功'
                    logger.info(info)
                    await message.channel.send(info)
                except Exception as e:
                    info = f'保存图片 {image_name_path} 失败: {e}'
                    logger.error(info)
                    await message.channel.send(info)

        # 有订单信息的时候判断
        if user_roll_map:
            if message.channel.id == SETTINGS.ORDER_CHANNEL_ID:
                # 只监听指定频道
                await roll_on_message(message)
            users = user_roll_map.keys()
            # 判断channel是否来自于私聊
            # 取消回复判断
            # if message.channel.type == discord.ChannelType.private \
            #         and message.author.id in users \
            #         and message.reference:
            #     # 判断message id所属user是否来自于roll
            #     # 判断是否为引用的消息
            #     # 判断消息是否在roll的pp_message中
            #     user = message.author
            #     roll_info = user_roll_map[message.author.id]
            #     for pp_message in roll_info.get('pp_message'):
            #         if message.reference.message_id != pp_message.id:
            #             continue
            #         # 如果是的话，意味着下单成功，放到 selected_pp_list 中
            #         # 获取pp_id
            #         pp_info = roll_info.get('pp_info').get(pp_message.id)
            #         user_roll_map[message.author.id]['selected_pp_list'].append(pp_info)
            #         await user.send(f'已选择: {pp_info.get("pp_name")}')
            if message.channel.type == discord.ChannelType.private \
                    and message.author.id in users and message.content.strip() in ['!end', '！end']:
                # 获取老板信息，如果老板发消息是 !end 则结束点单
                logger.info(f'老板 {message.author.name} 发送了 !end 指令: {message.content}')
                user = message.author
                roll_channel_id = SETTINGS.ORDER_CHANNEL_ID
                roll_channel = client.get_channel(roll_channel_id)
                roll_info = user_roll_map[user.id]

                # 检查所有私聊消息pp_private_message是否有反应
                selected_pp_id_set = set()
                notify_boss_str = ''
                for pp_private_message_id in list(roll_info['pp_private_message_pp_id_map']):
                    # 检查私聊消息，如果有反应则加入到 selected_pp_id_list 中
                    pri_msg = roll_info['pp_private_message'][pp_private_message_id]
                    pri_msg = await pri_msg.channel.fetch_message(pri_msg.id)
                    pri_msg_reactions = pri_msg.reactions

                    # 检查默认首个reaction是否大于1, 如果大于1则代表老板选择了
                    if pri_msg_reactions and pri_msg_reactions[0].count > 1:
                        pp_id = roll_info['pp_private_message_pp_id_map'][pri_msg.id]
                        selected_pp_id_set.add(pp_id)
                        pp_info = pp_share_info[pp_id]
                        pp_name = pp_info['pp_name']
                        notify_boss_str += f'『 {pp_name} 』'

                # 如果没有选择任何一个陪玩，则结束点单，公告发送流单
                if len(selected_pp_id_set) < 1:
                    logger.info(f'老板 {user.name} 没有选择任何一个陪玩，单子流掉了！')
                    await message.channel.send('🍃  呜呜，老板没有选择任何一个陪陪，单子流掉了！')
                    await delete_roll(None, user.id, roll_info['text'], roll_info['ref_msg_id'])
                    return

                # 将老板下单成功的embed发到公屏
                selected_pp_ids_list = [f'<@{pp_id}>' for pp_id in selected_pp_id_set]
                selected_pp_ids_str = ','.join(selected_pp_ids_list)
                mention_user = '匿名' if roll_info.get('anonymous') == AnonymousType.我要匿名 else user.mention

                report_embed = discord.Embed(
                    title='💗 点单成功！💗',
                    description=f'感谢『  {mention_user}  』老板大大点单『 {selected_pp_ids_str} 』\n'
                                f'也谢谢陪陪宝贝，愿INK给你们带来无穷快乐！(◍•ᴗ•◍) \n',
                    color=0xe8adb9
                )
                # 是否匿名
                if roll_info.get('anonymous') != AnonymousType.我要匿名:
                    report_embed.set_author(
                        name='',
                        icon_url=user.display_avatar.url
                    )
                else:
                    pass
                # 根据老板的 id 添加接单图片
                user_id = user.id
                order_img_info = order_custom_boss_info.get(str(user_id))
                if roll_info.get('anonymous') == AnonymousType.我要匿名 or not order_img_info:
                    report_embed.set_image(
                        url=f'https://media.discordapp.net/attachments/1040080636830040084/1087036277574094888/7.png'
                    )
                else:
                    report_embed.set_image(
                        url=order_img_info.get('url')
                    )
                await roll_channel.send(embed=report_embed)
                # 老板下单成功之后，删除老板的roll信息
                logger.info(f'老板下单成功，删除老板的roll信息: {user}')
                # 通知老板
                await user.send(f'🎏  恭喜老板大大，**下单成功！**INK娘正在去找 **{notify_boss_str}** 到位中！\n'
                                f'INK娘希望大大在INK  玩得开心 天天上分！')
                # 给陪玩私发消息
                for pp_id in selected_pp_id_set:
                    pp_info = pp_share_info[pp_id]
                    send_pp_embed = discord.Embed(
                        title='🎏 恭喜你被老板下单！',
                        description=f'恭喜你已经被『 {user.mention} 』老板选中『 {roll_info.get("text")} 』单，'
                                    f'快点去和老板报道叭~你是最棒哒~(๑•̀ㅂ•́)و\n'
                                    f'如果已经被选走的话，请尽快跟老板解释清楚哦',
                        color=user.color
                    )
                    send_pp_embed.set_author(
                        name=user.display_name,
                        icon_url=user.display_avatar.url
                    )
                    # 从下单channel寻找用户并发送消息
                    pp_user = await client.fetch_user(pp_info.get('pp_id'))
                    await pp_user.send(embed=send_pp_embed)
                    # 给点中的陪玩加积分
                    await add_user_score(pp_info.get('pp_id'), 1, 'pp_success')
                # 删除老板的roll信息
                try:
                    del user_roll_map[user.id]
                    # 保存
                    save_roll_map()
                except Exception as e:
                    logger.error(f'删除老板的roll信息失败: {e} {user_roll_map}')

            if message.channel.type == discord.ChannelType.private \
                    and message.author.id in users and message.content.strip() in ['!shiyin', '！shiyin']:
                user = message.author
                logger.info(f'老板 {user.display_name} 私聊要求试音')
                await user.send(f'🥁 INK娘已经跑去通知客服组织所有扣单陪陪试音咯，稍后会联系您 ~')

                roll_info = user_roll_map[user.id]
                order_text = roll_info.get("text")
                # 通知客服
                notify_channel = client.get_channel(SETTINGS.ORDER_NOTIFY_CHANNEL_ID)
                await notify_channel.send(f'[下单通知] 老板 {user.mention} 要求试音, 内容: {order_text}')
                order_channel = client.get_channel(SETTINGS.ORDER_CHANNEL_ID)
                order_boss_name = '匿名' if roll_info.get('anonymous') == AnonymousType.我要匿名 else user.mention
                await order_channel.send(f'🥁 『 {order_boss_name} 』 老板大大『  {order_text}  』要求试音，'
                                         f'请帮忙组织试音叭！ <@&{SETTINGS.CUSTOMER_SERVICE_ROLE_ID}>')
                # 给所有扣单的陪玩私发消息
                # for pp_id in roll_info['pp_id_pp_private_message_map'].keys():
                #     try:
                #         # 从下单channel寻找用户并发送消息
                #         pp_user = await client.fetch_user(pp_id)
                #         # 私聊消息通知试音
                #         await pp_user.send(f'🎉 老板要求试音，速来试音频道试音 <#{SETTINGS.VOICE_TEST_CHANNEL_ID}>')
                #         logger.info(f'给 {pp_user.display_name} 发送试音消息 老板是 {user.display_name}')
                #     except Exception as e:
                #         logger.error(f'给 {pp_id} 发送试音消息失败 老板是 {user.display_name} error: {e}')

            # if message.channel.type == discord.ChannelType.private \
            #         and message.author.id in users and message.content == '!list':
            #     user = message.author
            #     logger.info(f'老板 {user.display_name} 私聊要求查看陪玩列表')
            #     # 通知客服
            #     notify_channel = client.get_channel(SETTINGS.NOTIFY_CHANNEL_ID)
            #     await notify_channel.send(f'[通知] 老板 {user.display_name} 私聊要求查看陪玩列表')
            #
            #     roll_info = user_roll_map[user.id]
            #     # 显示所有陪玩的列表
            #     pp_list = roll_info.get('pp_info')
            #     pp_list_str = ''
            #     for pp_message, pp_info in pp_list.items():
            #         pp_list_str += f'{pp_info.get("pp_name")}\n'
            #     await user.send(f'陪玩列表：\n{pp_list_str}')

        # 游戏开始逻辑
        if message.channel.id in game_start_channels:
            # 加入游戏participants
            game_start_channels[message.channel.id]['participants'].add(message.author.id)

        # 送礼物逻辑
        gift_start_with_list = ['$yhj', '$br', '$yr']
        # 当前只用这种逻辑，临时
        gift_dict = {
            '$yhj': {
                'name': '印花集',
                'price': 6.6,
                "image_url": "https://media.discordapp.net/attachments/963181226414444544/1036669286384672848/unknown.png?width=1643&height=924",
            },
            '$br': {
                'name': '半日冠',
                'price': 66.0,
                "image_url": "https://media.discordapp.net/attachments/1036320111042236518/1038491409575067708/794AC5CE-A8CE-44C6-9696-8778F6B7C4BC.png?width=1659&height=933"
            },
            '$yr': {
                'name': '一日冠',
                'price': 131.4,
                "image_url": "https://media.discordapp.net/attachments/1040080636830040084/1070339887544418367/0ee844c8ddcb9ffc121e582b52124046.png?width=1875&height=1055"

            }
        }
        if message.content.startswith(tuple(gift_start_with_list)):
            message_content = message.content
            from_user = message.author.name
            logger.info(f'{from_user} 礼物赠送: {message_content}')
            message_mentions = message.mentions
            if len(message_mentions) < 2:
                await message.reply(f'Sorry, 人数不对哦')
            else:
                try:
                    gift = message_content.split()[0]
                    gift_name = gift_dict[gift]['name']
                    gift_price = gift_dict[gift]['price']
                    gift_img_url = gift_dict[gift]['image_url']
                except:
                    logger.warning(f'格式错误: {message_content}')
                    await message.reply(f'Sorry, 格式错误哦')
                else:
                    boss = message_mentions[0]
                    players = message_mentions[1:]
                    players_str = ' '.join([p.mention for p in players])
                    # gift_embed = discord.Embed(
                    #     title=f'🎁 {gift_name}',
                    #     description=,
                    #     color=0x00ff00
                    # )
                    response_text = f'感谢超级大方的{boss.mention}送给 {players_str} 的{gift_name}！\n感谢老板！\n心动值+{gift_price}点'
                    img_url = 'https://cdn.discordapp.com/attachments/1051765597677035541/1109387603310022676/20.png'
                    current_channel = message.channel

                    await current_channel.send(response_text)
                    await current_channel.send(img_url)

                    # 第二个播报到指定频道
                    gift_2_channel = 926619981981044747
                    gift_2_channel = await client.fetch_channel(gift_2_channel)
                    # gift_embed.set_image(url=gift_img_url)
                    await gift_2_channel.send(response_text)
                    await gift_2_channel.send(gift_img_url)


intents = discord.Intents.default()
intents.dm_messages = True
intents.message_content = True
client = MyClient(intents=intents)


@client.event
async def on_message_delete(message: discord.Message):
    """删除消息反馈"""
    # 监听下单的消息是否被删除
    if message.channel.id == SETTINGS.ORDER_CHANNEL_ID:
        for user in user_roll_map.keys():
            roll_info = user_roll_map[user]
            if message.id in roll_info['pp_channel_messages_id_list'].keys():
                logger.info(f'下单消息被删除: {message.content}')
                # 找到pp id
                pp_id = roll_info['pp_channel_message_id_pp_id_map'][message.id]
                # 给点中的陪玩减积分
                pp_info = pp_share_info.get(pp_id)
                pp_name = pp_info.get('pp_name')
                to_delete_private_msg_id = roll_info['pp_id_pp_private_message_map'][pp_id]
                await add_user_score(pp_id, -0.1, 'pp_cancel')

                try:
                    await roll_info['pp_private_message'][to_delete_private_msg_id].delete()
                    roll_info['pp_private_message'].pop(to_delete_private_msg_id)
                    roll_info['pp_private_message_pp_id_map'].pop(to_delete_private_msg_id)
                    roll_info['pp_id_pp_private_message_map'].pop(pp_id)
                    roll_info['pp_channel_messages_id_list'].pop(message.id)
                    roll_info['pp_id_channel_message_pp_id_map'].pop(pp_id)
                    roll_info['pp_channel_message_id_pp_id_map'].pop(message.id)
                except Exception as e:
                    logger.error(f'删除下单消息相关信息失败: {e}')

                # 给老板发送取消下单成功消息
                user = await client.fetch_user(user)
                await user.send(f'陪陪已经取消扣单: {pp_name}！')
                channel = client.get_channel(SETTINGS.ORDER_CHANNEL_ID)
                await channel.send(f'陪陪已经取消扣单: {pp_name}！')
                return


# 装饰器，用于在NOTIFY_CHANNEL通知管理员谁用了什么命令和参数
def notify_admin(func):
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        # try:
        #     notify_channel = client.get_channel(SETTINGS.DEFAULT_NOTIFY_CHANNEL_ID)
        #     interaction: discord.Interaction = args[0]
        #     await notify_channel.send(f'[通知] {interaction.user.display_name} 使用了 {func.__name__} 命令')
        # except Exception as e:
        #     logger.warning(f'notify_admin error: {e}')
        # 暂时删除
        await func(*args, **kwargs)

    return wrapper


async def roll_on_message(message: discord.Message):
    """当开始抢单时，监听消息"""
    for user in user_roll_map:
        roll_info = user_roll_map[user]
        # 如果message的用户id已经存在则忽略
        if message.author.id in roll_info['pp_id_pp_private_message_map'].keys():
            continue
        # 如果message的用户id不在sent_user中，则判断是否有抢单的关键字
        command = roll_info.get('command')
        user_id = roll_info.get('user_id')
        user = await client.fetch_user(user_id)
        # 如果聊天记录里面有command字段，那么发送图片给当前用户
        # 如果聊天记录和command不同，那么不做任何操作
        if command in message.content:
            # 发送该用户id的图片
            # 如果没有图片，则只发内容
            try:
                private_pp_img_message = await user.send(
                    f'陪陪 {message.author.display_name} 发来消息: {message.content}',
                    file=discord.File(f'images/{message.author.id}.png')
                )
            except Exception as e:
                private_pp_img_message = await user.send(
                    f'陪陪 {message.author.display_name} 发来消息: {message.content} '
                    f'没有找到陪陪的图片，但是可以点哦: {message.author.display_name}'
                )
                logger.warning(f'没有找到陪陪的图片: {e}')
            await private_pp_img_message.add_reaction('🍟')

            # 建立陪玩id、私聊信息、频道消息的id相互映射
            roll_info['pp_private_message'][private_pp_img_message.id] = private_pp_img_message
            roll_info['pp_private_message_pp_id_map'][private_pp_img_message.id] = message.author.id
            roll_info['pp_id_pp_private_message_map'][message.author.id] = private_pp_img_message.id

            roll_info['pp_channel_messages_id_list'][message.id] = message
            roll_info['pp_id_channel_message_pp_id_map'][message.author.id] = message.id
            roll_info['pp_channel_message_id_pp_id_map'][message.id] = message.author.id

            # 记录陪玩信息
            pp_share_info[message.author.id] = {
                'pp_id': message.author.id,
                'pp_name': message.author.display_name,
            }

            # 用户积分加上0.1
            await add_user_score(message.author.id, 0.1, 'roll_on_message')

    save_roll_map()


async def get_user_info(user_id):
    """从数据库中获取指定id的用户信息,返回dict类型"""
    user_id = str(user_id)
    query = user_info.select().where(user_info.c.id == user_id)
    result = await database.fetch_one(query)
    if result:
        return dict(result)
    return {}


@client.tree.command()
@app_commands.describe(
    最小值='最小值',
    最大值='最大值',
    随机次数='随机次数'
)
@notify_admin
async def rand(interaction: discord.Interaction, 最小值: int, 最大值: int, 随机次数: int = 1):
    """摇骰子"""
    # 生成随机数n次，生成的随机数从t_min到t_max，包含t_min和t_max
    prepare = [i for i in range(最小值, 最大值 + 1)]
    result = []
    for i in range(随机次数):
        # 生成随机数从prepare中随机选择一个，加入到result后删除
        random_num = random.choice(prepare)
        result.append(random_num)
        prepare.remove(random_num)
    await interaction.response.send_message(f'🎲你摇出来了: {result}')


@client.tree.command()
@app_commands.describe(
    抽奖内容='抽奖内容',
    抽奖时间='抽奖时间',
    中奖人数='开奖人数',
    是否匿名='是否匿名',
)
# @app_commands.checks.has_permissions(administrator=True)
async def roll(
        interaction: discord.Interaction,
        抽奖内容: str,
        中奖人数: int,
        是否匿名: AnonymousType,
        抽奖时间: int = 30,
):
    """抽奖功能"""
    if interaction.channel_id != SETTINGS.ROLL_CHANNEL_ID:
        await interaction.response.send_message('请到抽奖频道使用', ephemeral=True)
        return
    # 保留抽奖口令
    code = ''

    if 抽奖时间 > SETTINGS.GIVEAWAY_MAX_MINUTES:
        await interaction.response.send_message(f'Sorry, 只支持{SETTINGS.GIVEAWAY_MAX_MINUTES}分钟内的设定',
                                                ephemeral=True)

    user = '匿名老板' if 是否匿名 == AnonymousType.我要匿名 else interaction.user.mention

    embed = discord.Embed(
        title='🎟️  抽奖活动  正在进行中！🎟️ ',
        # {interaction.user.display_name}
        description=f"""💎 感恩『 {user} 』金主大大   赞助了本轮抽奖！""",
        color=0xd96370
    )
    embed.timestamp = interaction.created_at
    start_time = datetime.now(pytz.timezone(SETTINGS.TIMEZONE))
    end_time = start_time + timedelta(minutes=抽奖时间)
    # end_time = start_time + timedelta(seconds=10)
    end_time_format = end_time.strftime('%Y-%m-%d %H:%M:%S')
    job_id = int(time.time()) + int(random.random() / 10000)
    logger.info(f'{抽奖内容} 增加 {job_id} 抽奖定时器: {end_time}')

    at_text = ''
    # 提取text中的mention到的成员
    members = re.findall(r'<@!?\d+>', 抽奖内容)
    # 提取text中的role到的成员
    roles = re.findall(r'<@&\d+>', 抽奖内容)
    # 如果有mention到的成员，则在下单信息中添加提醒
    if members:
        # 频道中发送mention成员消息
        at_text += ' '.join(members)
    if roles:
        at_text += ' '.join(roles)
    if at_text:
        # 删除text中的mention到的成员和身分组
        抽奖内容 = re.sub(r'<@!?\d+>', '', 抽奖内容)
        抽奖内容 = re.sub(r'<@&\d+>', '', 抽奖内容)

    embed.add_field(name="🔸 抽奖感言", value=抽奖内容 + f"""\n
         中奖人数**『  {中奖人数}  』**人
         距离开奖还有 **『 {抽奖时间} 』**分钟！""", inline=False)
    # embed.add_field(name='抽奖𝑰𝑫 ', value=f'{job_id}', inline=False)
    # embed.add_field(name='抽奖口令', value=f'{code}', inline=False)
    embed.add_field(name='▫️ 开奖时间(EST)', value=f'{end_time_format}\n'
                                                   f'快快**点击下方 🎉 表情**参与抽奖叭！ヾ(０∀０★)ﾟ･.｡', inline=False)

    # 给交互的channel发消息
    channel_id = interaction.channel_id
    channel = client.get_channel(channel_id)
    if at_text:
        await channel.send(at_text)
    message = await channel.send(embed=embed)
    # 通知客服
    user = interaction.user
    await client.get_channel(SETTINGS.ROLL_NOTIFY_CHANNEL_ID).send(
        f'[抽奖通知] 老板发出抽奖 {user.mention} 抽奖 {抽奖内容} 抽奖id {job_id} 抽奖时间 {抽奖时间} 分'
        f'中奖人数 {中奖人数} {是否匿名.value}'
    )
    await message.add_reaction('🎉')
    try:
        await interaction.response.send_message('抽奖已经开始！', ephemeral=True)
    except Exception as e:
        logger.warning(f'抽奖回复消息失败：{e}')
        # await channel.send('抽奖已经开始！')

    # 开奖embed
    basic_embed = discord.Embed(
        title='🎊   恭喜幸运鹅！开奖啦！ 🎊',
        description=f'抽奖活动已经开奖！没抽中的宝贝不要灰心，没关系，人生处处是惊喜！｡･ﾟヾ(✦థ ｪ థ)ﾉ｡ﾟ･｡',
        color=discord.Color.green()
    )
    # 添加图片
    basic_embed.set_image(url='https://cdn.discordapp.com/attachments/1073833861999505408/1090539459910578226/20.png')
    basic_embed.add_field(name='🔸 抽奖内容', value=f'{抽奖内容}', inline=False)
    # basic_embed.add_field(name='🔸 幸运鹅', value=f'**{winners}**', inline=False)

    # 增加一个定时器
    job = client.scheduler.add_job(
        giveaway, trigger=DateTrigger(run_date=end_time),
        args=[basic_embed, message.id, channel_id, 中奖人数, interaction.user.id, 抽奖内容],
        id=str(job_id)
    )
    # job_id = job.id

    query = giveaways.insert().values(
        id=job_id,
        code=code,
        start_time=start_time,
        end_time=end_time,
        minutes=抽奖时间,
        winners=中奖人数,
        activate=True
    )
    await database.execute(query)
    logger.info(f'inserted giveaway: {job_id}')


@client.tree.command()
@notify_admin
async def gall(
        interaction: discord.Interaction,
):
    """显示所有当前的抽奖"""
    if interaction.channel_id != SETTINGS.ADMIN_CHANNEL_ID:
        await interaction.response.send_message('请到管理员频道使用', ephemeral=True)
        return
    query = giveaways.select().where(
        giveaways.c.activate == True,
        giveaways.c.end_time > datetime.now(pytz.timezone(SETTINGS.TIMEZONE))
    )
    result = await database.fetch_all(query)
    logger.info(f'got all activated giveaways: {result}')
    embed = discord.Embed(
        title='🖊当前抽奖列表',
        color=interaction.user.color
    )
    if not result:
        embed.description = '空……'
    for res in result:
        id, code, start_time, end_time, _, winners, _ = res
        start_time = start_time.strftime('%m-%d %H:%M:%S')
        end_time = end_time.strftime('%m-%d %H:%M:%S')
        # temp_output.append([str(id), code, str(winners), start_time, end_time])
        embed.add_field(
            name=f'**ID: {id}**',
            value=f'> 抽奖口令: {code}\n> 开奖人数: {winners}\n> 开始时间: {start_time}\n> 结束时间: {end_time}',
            inline=False
        )
    await interaction.response.send_message(embed=embed, ephemeral=True)

    # @client.tree.command()
    # @app_commands.describe(
    #     gid='抽奖ID'
    # )
    # async def gstop(
    #         interaction: discord.Interaction,
    #         gid: str
    # ):
    #     """停止某一个抽奖"""
    #     # 判断当前消息是否来自管理员频道ID
    #     if interaction.channel_id != SETTINGS.ADMIN_CHANNEL_ID:
    #         await interaction.response.send_message('只有管理员才能使用该命令', ephemeral=True)
    #         return
    #     query = giveaways.update().where(giveaways.c.id == gid).values(activate=False)
    #     result = await database.execute(query)
    #     logger.info(f'stop giveaway: {gid} {result}')
    #     if not result:
    #         await interaction.response.send_message(f'不存在改抽奖ID: {result}', ephemeral=True)
    #     # todo cron to clear
    #     try:
    #         # 定时器的任务移除
    #         client.scheduler.remove_job(gid)
    #     except JobLookupError:
    #         logger.warning(f'have not this giveaway id: {gid}')
    await interaction.response.send_message(f'停止抽奖: {result}', ephemeral=True)


@client.tree.command()
@notify_admin
async def gclear(
        interaction: discord.Interaction,
):
    """清空所有抽奖(管理员可用)"""
    # 判断当前消息是否来自管理员频道ID
    if interaction.channel_id != SETTINGS.ADMIN_CHANNEL_ID:
        await interaction.response.send_message('只有管理员才能使用该命令', ephemeral=True)
        return
    query = giveaways.select().where(giveaways.c.activate == True)
    result = await database.fetch_all(query)
    for res in result:
        gid, _, _, _, _, _, _ = res
        try:
            client.scheduler.remove_job(str(gid))
        except JobLookupError:
            logger.warning(f'have not this giveaway id: {gid}')
    query = giveaways.update().where(giveaways.c.activate == True).values(activate=False)
    result = await database.execute(query)
    logger.info(f'stop all giveaway: {result}')
    await interaction.response.send_message(f'停止所有抽奖')


@client.tree.command()
@app_commands.describe(
    成员='看指定成员的加入时间，不输入则默认为当前发出指令的成员'
)
@notify_admin
async def joined(interaction: discord.Interaction, 成员: Optional[discord.Member] = None):
    """显示member的加入时间"""
    member = 成员 or interaction.user
    await interaction.response.send_message(f'{member} joined {discord.utils.format_dt(member.joined_at)}',
                                            ephemeral=True)


@client.tree.command()
@app_commands.describe(
    成员='看指定成员的积分，不输入则默认为当前发出指令的成员'
)
@notify_admin
async def rank(interaction: discord.Interaction, 成员: Optional[discord.Member] = None):
    """显示member的积分"""
    member = 成员 or interaction.user
    # 获取成员id的积分
    user_id = member.id
    result = await get_user_info(user_id)
    if result:
        score = result['total_score']
    else:
        score = 0
        logger.warning(f'{member} {user_id} 当前没有积分')
    await interaction.response.send_message(f'{member} 当前积分为 {score}', ephemeral=True)


async def giveaway(
        basic_embed: discord.Embed,
        message_id: int,
        channel_id: int,
        winners,
        order_user_id: int,
        giveaway_text: str
):
    """在discord指定的channel中发抽奖中奖的消息"""
    await client.wait_until_ready()
    # 抽奖的channel
    channel = client.get_channel(channel_id)
    if not channel:
        logger.warning(f'channel id 错误: {channel_id}')
        return

    message = await channel.fetch_message(message_id)
    users = set()
    for reaction in message.reactions:
        # if reaction.emoji != '🎉':
        #     continue
        async for reaction_user in reaction.users():
            if reaction_user.bot is True:
                continue
            users.add(reaction_user)

    if not users:
        logger.info(f'no users: {message_id}')

    try:
        with open('surprise.json', 'r', encoding='utf-8') as f:
            surprise_members_info = json.load(f)
    except FileNotFoundError:
        surprise_members_info = {}

    order_user = await client.fetch_user(order_user_id)
    if not users:
        # 没有中奖的处理
        basic_embed.add_field(name='🔹 阿欧，没有人中奖', value='再来一次，再来一次!')
        # 通知老板
        await order_user.send(f'🍃  通知：没有人抽中了您『 {giveaway_text} 』的奖品！再来一次！再来一次叭！')
    else:
        # 随机抽取一个成员
        if len(users) < winners:
            winners = len(users)
        lucky_members = random.sample(list(users), winners)
        # 使用@的形式提到中奖人员
        members_msg = ''
        for member in lucky_members:
            # 如果有彩蛋成员，打印特殊效果
            if str(member.id) in surprise_members_info:
                await channel.send(f'恭喜彩蛋成员 {member.mention} 中奖了！')
            members_msg += f'{member.mention},'
            # 单独私聊每一个中奖的成员信息
            await member.send(f'🎁 ᑋᵉᑊᑊᵒ ᵕ̈ 恭喜您在INK {channel.mention} 中奖了！快去看看吧！'
                              f'记得谢谢老板 {order_user.mention} 喔~ ')
        # 删除members_msg最后一个逗号
        members_msg = members_msg[:-1]
        basic_embed.add_field(name='🔸 幸运鹅', value=f'{members_msg}', inline=False)
        # 通知老板
        logger.info(f'通知老板中奖: {order_user} {giveaway_text} {members_msg} ')
        # 通知客服
        notify_channel = client.get_channel(SETTINGS.ROLL_NOTIFY_CHANNEL_ID)
        await notify_channel.send(
            f'[抽奖通知] [{members_msg}] 抽中了 老板 {order_user.mention} {order_user.display_name} 奖品：'
            f' [{giveaway_text}] ')

        await order_user.send(f'🎁  通知：[{members_msg}]抽中了您[{giveaway_text}]的奖品！✿✿ヽ感恩！ ')

    await channel.send(embed=basic_embed)


async def add_user_score(user_id: int, score: float, score_type: str = ''):
    """给某个用户增加积分的数据库操作
    :param user_id: 用户的id
    :param score: 增加的积分
    :param score_type: 积分的类型，默认为空，预留扩展"""
    query = user_info.select().where(user_id == user_info.c.id)
    result = await database.fetch_one(query)
    if result:
        # 如果有记录，则更新
        to_add_score = result['total_score'] if result['total_score'] else 0.0
        to_add_score = round(to_add_score + score, 2)
        if to_add_score < 0:
            to_add_score = 0.0
        query = user_info.update().where(user_id == user_info.c.id).values(total_score=to_add_score)
        result = await database.execute(query)
        logger.info(f'update user {user_id} score: {score}')
    else:
        # 如果没有记录，则插入
        if score < 0:
            score = 0.0
        query = user_info.insert().values(id=user_id, total_score=score)
        result = await database.execute(query)
        logger.info(f'insert user {user_id} score: {score} result: {result}')
    # 记录积分变动
    query = user_score.insert().values(user_id=user_id, score=score, score_type=score_type)
    result = await database.execute(query)
    logger.info(f'insert user {user_id} score type: {score} result: {result}')


async def delete_roll(roll_id, user_id, text, message_id):
    """删除下单"""
    # 设置giveaways的状态为已删除
    logger.info(f'删除本次老板下单: {user_id}')
    if user_id not in user_roll_map:
        logger.info(f'用户 {user_id} 无下单记录，可能为已经流单')
        return
    del user_roll_map[user_id]
    save_roll_map()
    # 下单频道发送信息
    channel = client.get_channel(SETTINGS.ORDER_CHANNEL_ID)
    # 引用message_id消息说明下单已经失效
    embed = discord.Embed(
        title='🌂 老板带着单子逃跑啦！🌂',
        color=discord.Color.red(),
    )
    embed.add_field(name='🔸下单内容', value=f'{text}\n\n‿︵‿︵‿︵‿ヽ(°□° )ノ︵‿︵‿︵‿︵\n啊啊啊，咕噜噜....', inline=False)
    # 发送流单图片
    embed.set_image(
        url='https://media.discordapp.net/attachments/1040080636830040084/1081763802946740234/e8dafa5d4e9fa9c6c56359f1756cd92.png?width=1920&height=705')
    await channel.send(
        embed=embed,
        reference=discord.MessageReference(message_id=message_id, channel_id=channel.id, guild_id=channel.guild.id)
    )
    # 通知客服
    notify_channel = client.get_channel(SETTINGS.ORDER_NOTIFY_CHANNEL_ID)
    await notify_channel.send(f'[流单通知] 老板 <@{user_id}> 下单内容 {text} 已经流单了！')

    if roll_id:
        # 给老板发消息告知流单
        user = await client.fetch_user(user_id)
        await user.send(f'🍃  您的订单已经超时流单了哦！')


@client.tree.command()
@app_commands.describe(
    下单需求='点单需求，可以@对应陪陪标签',
    自定义扣单口令='自定义扣单口令',
    是否匿名='老板是不是要匿名呢？',
    是否试音='选择是否需要试音哦！'
    # minutes='分钟数'
)
async def order(
        interaction: discord.Interaction,
        下单需求: str,
        自定义扣单口令: str,
        是否匿名: AnonymousType,
        是否试音: VoiceTestType
        # minutes: int = 10
):
    """下单"""
    # 抢单下单channel id
    channel = client.get_channel(SETTINGS.ORDER_CHANNEL_ID)
    if not channel:
        logger.warning(f'channel id 错误: {SETTINGS.ORDER_CHANNEL_ID}')

    # 查看自定义扣单口令是否已存在 user_roll_map里面的command
    command_list = [v['command'] for v in user_roll_map.values()]
    if 自定义扣单口令 in command_list:
        logger.warning(f'当前{自定义扣单口令}已经重复')
        await interaction.response.send_message(f'抱歉！当前自定义扣单口令重复：{自定义扣单口令}')
        return

    # 默认15分钟后确定
    minutes = 15
    start_time = datetime.now(pytz.timezone(SETTINGS.TIMEZONE))
    end_time = start_time + timedelta(minutes=minutes)
    end_time_format = end_time.strftime('%Y-%m-%d %H:%M:%S')

    roll_id = str(uuid.uuid4())
    user_id = interaction.user.id
    # fixme at text直接用下单需求
    at_text = 下单需求
    # # 提取text中的mention到的成员
    # members = re.findall(r'<@!?\d+>', 下单需求)
    # # 提取text中的role到的成员
    # roles = re.findall(r'<@&\d+>', 下单需求)
    # # 如果有mention到的成员，则在下单信息中添加提醒
    # if members:
    #     # 频道中发送mention成员消息
    #     at_text += ' '.join(members)
    # if roles:
    #     at_text += ' '.join(roles)
    if at_text:
        await channel.send(at_text)

    embed = discord.Embed(
        title='✅  订单生成   ٩(●˙▿˙●)۶… 开始扣单！✅ ',
        color=discord.Color.green(),
    )
    # 删除text中的mention到的成员和身分组
    # 下单需求 = re.sub(r'<@!?\d+>', '', 下单需求)
    # 下单需求 = re.sub(r'<@&\d+>', '', 下单需求)
    if 是否匿名 == AnonymousType.不要匿名:
        embed.add_field(name='🔸老板大大', value=f'{interaction.user.mention}', inline=False)
    # embed.add_field(name='🔸下单需求', value=f'{下单需求}', inline=False)
    embed.add_field(name='🔸抢单口令 ', value=f'扣『 {自定义扣单口令} 』参与抢单', inline=False)
    if 是否试音 != VoiceTestType.不用试音:
        if 是否试音 == VoiceTestType.需要试音:
            embed.add_field(name='🔸试音需求', value=f'试音召唤！~  ᕙ༼◕_◕༽ᕤ',
                            inline=False)
            # embed.add_field(name='🔸试音厅', value=f'<#{SETTINGS.VOICE_TEST_CHANNEL_ID}>', inline=False)
        elif 是否试音 == VoiceTestType.可能试音:
            embed.add_field(name='🔸试音需求', value=f'可能试音！~  ᕙ༼◕_◕༽ᕤ',
                            inline=False)
            # embed.add_field(name='🔸试音厅', value=f'<#{SETTINGS.VOICE_TEST_CHANNEL_ID}>', inline=False)
    embed.add_field(name='🔸扣单截止时间 (EST)', value=f'{end_time_format}')
    embed.timestamp = interaction.created_at

    # 抢单的text删除提取到的members和roles
    # response_text = 下单内容.replace(f'@{下单命令}', '').strip()
    # embed.add_field(name='🔸老板要求', value=f'{response_text}', inline=False)
    # 私聊当前的用户
    _ = await interaction.user.send(
        f"""✅  **感谢老板大大，订单已生成！**✅
        
```glsl
# 🍡【选择陪陪】点击中意陪陪名片（或文字）下自带的表情
# 🍡【点单试音】在这里输入『!shiyin』指令
# 🍡【完成下单】在这里输入『!end』指令
```
一定要输入『 !end 』指令完成下单！下单成功，会收到确认信息喔！
没有看中陪陪，可直接『 !end 』指令流单"""
    )
    # 默认回复响应
    try:
        await interaction.response.send_message('下单成功', ephemeral=True)
    except Exception as e:
        logger.error(f'发送消息错误，使用频道发送: {e}')
        # await channel.send(f'老板下单成功')
    # 老板下单，积分增加
    await add_user_score(user_id, 1, 'roll')
    logger.info(f'roll user: {interaction.user} score: 1')

    job_id = int(time.time()) + int(random.random() / 10000)

    message = await channel.send(embed=embed)
    # 通知客服
    await client.get_channel(SETTINGS.ORDER_NOTIFY_CHANNEL_ID).send(
        f'[下单通知] 老板 {interaction.user.mention} 下单内容: {下单需求} 扣单口令: {自定义扣单口令} 匿名: {是否匿名}'
    )
    # 时间到期公告已停止下单
    job = client.scheduler.add_job(
        delete_roll, trigger=DateTrigger(run_date=end_time),
        args=[roll_id, user_id, 下单需求, message.id],
        id=str(job_id)
    )
    logger.info(f'增加 {job_id} 当前时间 {start_time} 下单定时器: {end_time} roll message: {message.id} '
                f'command: {自定义扣单口令} '
                f'user: {interaction.user} ')

    # 保存相关数据供使用
    user_roll_map[user_id] = {
        'job_id': job_id,
        'roll_id': roll_id,
        'text': 下单需求,
        'ref_msg_id': message.id,
        'command': str(自定义扣单口令),
        'user_id': interaction.user.id,
        'end_time': end_time,
        'pp_private_message': {},
        'pp_private_message_pp_id_map': {},
        'pp_id_pp_private_message_map': {},
        'pp_channel_messages_id_list': {},
        'pp_id_channel_message_pp_id_map': {},
        'pp_channel_message_id_pp_id_map': {},
        'anonymous': 是否匿名
    }
    save_roll_map()
    return


def recover_old_name(channel_id, member_id, old_name):
    """将old_name恢复为new_name"""
    channel = client.get_channel(channel_id)
    if not channel:
        logger.warning(f'channel id 错误: {channel_id}')
    member = channel.guild.get_member(member_id)
    if not member:
        logger.warning(f'no member {member_id}')
    try:
        member.edit(nick=old_name)
    except discord.errors.Forbidden:
        logger.warning(f'恢复 {old_name} 昵称失败，权限不足')
        return
    logger.info(f'恢复 {member_id} 昵称为 {old_name}')


# 获取用户生日
@client.tree.command()
@app_commands.describe(
    成员='看指定成员的生日，不输入则默认为当前发出指令的成员'
)
@notify_admin
async def birthday(interaction: discord.Interaction, 成员: discord.Member = None):
    """获取用户生日"""
    # 判断当前消息是否来自管理员频道ID
    if interaction.channel_id != SETTINGS.BIRTHDAY_CHANNEL_ID:
        await interaction.response.send_message('请到生日频道使用', ephemeral=True)
        return
    member = 成员
    member = member or interaction.user
    user_info_detail = await get_user_info(member.id)
    # 返回消息告知当前用户信息
    birthday_month = user_info_detail.get("birthday_month")
    birthday_day = user_info_detail.get("birthday_day")
    logger.info(f'获取 {member} {member.id} 生日: {user_info_detail}')
    await interaction.response.send_message(f'{member} 生日为 {birthday_month}-{birthday_day}', ephemeral=True)


@client.tree.command()
@app_commands.describe(
    成员id='成员ID',
    生日月="生日月",
    生日日="生日日",
)
async def set_birthday(interaction: discord.Interaction, 成员id: str, 生日月: int, 生日日: int):
    """记录成员的生日"""
    user_id = 成员id
    month = 生日月
    day = 生日日
    # 判断当前消息是否来自管理员频道ID
    if interaction.channel_id != SETTINGS.ADMIN_CHANNEL_ID:
        await interaction.response.send_message('只有管理员才能使用该命令', ephemeral=True)
        return
    # 检查月日是否合法
    if not (1 <= month <= 12 and 1 <= day <= 31):
        await interaction.response.send_message('月日不合法', ephemeral=True)
        return

    # 获取用户
    # user = interaction.user
    # 将用户生日记录到数据库中，当不存在该用户的时候新增，存在的时候更新
    result = await get_user_info(user_id)
    if result:
        query = user_info.update().where(user_info.c.id == user_id).values(
            birthday_month=month,
            birthday_day=day
        )
        result = await database.execute(query)
        logger.info(f'更新 {user_id} 生日为 {month} 月 {day} 日')
    else:
        query = user_info.insert().values(
            id=user_id,
            birthday_month=month,
            birthday_day=day,
        )
        result = await database.execute(query)
        logger.info(f'新增 {user_id} 生日为 {month} 月 {day} 日')
    await interaction.response.send_message(f'{user_id} 的生日已经设置为 {month}-{day}', ephemeral=True)


async def check_birthday():
    """检查数据库，给当天生日的人发送祝福"""
    # 获取当天日期
    today = datetime.now(pytz.timezone(SETTINGS.TIMEZONE))
    today_month = today.month
    today_day = today.day
    # 查询当天生日的人
    query = user_info.select().where(
        user_info.c.birthday_month == today_month,
        user_info.c.birthday_day == today_day
    )
    result = await database.fetch_all(query)
    # 如果没有人生日，直接返回
    if not result:
        return
    # 如果有人生日，获取生日人的id
    birthday_ids = [item['id'] for item in result]
    channel = client.get_channel(SETTINGS.BIRTHDAY_CHANNEL_ID)
    logger.info(
        f'生日频道 {channel.name} {SETTINGS.BIRTHDAY_CHANNEL_ID} 今天有 {len(birthday_ids)} 人生日: {birthday_ids}')
    for birthday_id in birthday_ids:
        # 使用intents获取生日人员的信息
        birthday_member: Member = await channel.guild.fetch_member(int(birthday_id))
        if not birthday_member:
            logger.warning(f'no member {birthday_id}')
            continue
        new_name = f'{CONSTS.BIRTHDAY_NAME}{birthday_member.name}'
        # 修改昵称
        try:
            await birthday_member.edit(nick=new_name)
        except Exception as e:
            logger.warning(f'修改 {birthday_member} 昵称失败: {e}')
            await channel.send(f'修改 {birthday_member} 昵称失败: {e}')
        else:
            await channel.send(f'今天是 <@{birthday_id}> 的生日，祝他生日快乐！')


async def recover_birthday_name():
    """恢复前一天生日的所有成员的名字"""
    # 查询数据库中昨天生日的所有成员
    yesterday = datetime.now(pytz.timezone(SETTINGS.TIMEZONE)) - timedelta(days=1)
    yesterday_month = yesterday.month
    yesterday_day = yesterday.day
    query = user_info.select().where(
        user_info.c.birthday_month == yesterday_month,
        user_info.c.birthday_day == yesterday_day
    )
    result = await database.fetch_all(query)
    # 如果没有人生日，直接返回
    if not result:
        return
    # 如果有人生日，获取生日人的id
    birthday_ids = [item['id'] for item in result]
    channel = client.get_channel(SETTINGS.BIRTHDAY_CHANNEL_ID)
    logger.info(f'昨天生日的人有 {birthday_ids}，恢复名字')
    for birthday_id in birthday_ids:
        # 使用intents获取生日人员的信息
        birthday_member: Member = await channel.guild.fetch_member(int(birthday_id))
        if not birthday_member:
            logger.warning(f'no member {birthday_id}')
            continue
        new_name = birthday_member.name.replace(CONSTS.BIRTHDAY_NAME, '')
        # 修改昵称
        try:
            await birthday_member.edit(nick=new_name)
        except Exception as e:
            logger.warning(f'修改 {birthday_member} 昵称失败: {e}')
        else:
            logger.info(f'修改 {birthday_member} 昵称成功: {new_name}')


def get_score_exchange_details(exchange_id):
    """获取积分兑换详情"""
    query = score_exchange.select().where(score_exchange.c.id == exchange_id)
    result = database.fetch_one(query)
    return result


def get_all_score_exchange():
    """获取所有积分兑换详情"""
    query = score_exchange.select()
    result = database.fetch_all(query)
    return result


# 装饰器，用于检查interaction的消息是否来自某个频道ID
# def check_channel(func):
#     @wraps(func)
#     async def wrapper(*args, **kwargs):
#         interaction = args[0]
#         if interaction.channel_id != channel_id:
#             await interaction.response.send_message('此命令只能在指定频道使用')
#             return
#         return await func(*args, **kwargs)
#
#     return wrapper


@client.tree.command()
@app_commands.describe(
    details='积分兑换内容',
    score='所需兑换积分'
)
@notify_admin
async def add_exchange(interaction: discord.Interaction, details: str, score: int):
    """添加积分兑换内容"""
    # 判断当前消息是否来自管理员频道ID
    if interaction.channel_id != SETTINGS.ADMIN_CHANNEL_ID:
        await interaction.response.send_message('只有管理员才能使用该命令', ephemeral=True)
        return

    # 获取用户
    user = interaction.user
    # 新增积分兑换项
    query = score_exchange.insert().values(
        details=details,
        score=score,
    )
    result = await database.execute(query)
    logger.info(f'{user.display_name} 新增兑换内容 {details}，所需积分为 {score}')
    await interaction.response.send_message(f'新增 {details}，所需积分为 {score}', ephemeral=True)


@client.tree.command()
@app_commands.describe(
    积分id='积分id',
)
@notify_admin
async def delete_exchange(interaction: discord.Interaction, 积分id: int):
    """删除积分兑换内容"""
    exchange_id = 积分id
    # 判断当前消息是否来自管理员频道ID
    if interaction.channel_id != SETTINGS.ADMIN_CHANNEL_ID:
        await interaction.response.send_message('只有管理员才能使用该命令', ephemeral=True)
        return
    # 获取用户
    user = interaction.user
    # 查询该项内容
    exist_result = await get_score_exchange_details(exchange_id)
    # 提取积分兑换内容
    details, score = exist_result['details'], exist_result['score']
    query = score_exchange.delete().where(
        score_exchange.c.id == exchange_id,
    )
    delete_result = await database.execute(query)

    logger.info(f'{user.display_name} 删除 {exchange_id} 兑换: {details}')
    await interaction.response.send_message(f'删除兑换ID {exchange_id}: {details}', ephemeral=True)


@client.tree.command()
@app_commands.describe(
    exchange_id='积分id',
    update_details='兑换详细内容',
)
@notify_admin
async def update_exchange(interaction: discord.Interaction, exchange_id: int, update_details: str):
    """更新积分兑换内容"""
    # 判断当前消息是否来自管理员频道ID
    if interaction.channel_id != SETTINGS.ADMIN_CHANNEL_ID:
        await interaction.response.send_message('只有管理员才能使用该命令', ephemeral=True)
        return
    # 获取用户
    user = interaction.user
    # 查询该项内容
    exist_result = await get_score_exchange_details(exchange_id)
    # 提取积分兑换内容
    details, score = exist_result['details'], exist_result['score']
    query = score_exchange.update().where(
        score_exchange.c.id == exchange_id,
    ).values(
        details=update_details
    )
    update_result = await database.execute(query)
    logger.info(f'{user.display_name} 更新 {exchange_id} 兑换: {details}: {update_result}')
    await interaction.response.send_message(f'更新兑换ID {exchange_id}: {details}', ephemeral=True)


@client.tree.command()
@notify_admin
async def shop(interaction: discord.Interaction):
    """查看积分兑换表"""
    if interaction.channel_id != SETTINGS.SHOP_CHANNEL_ID:
        await interaction.response.send_message('请到聊天频道使用', ephemeral=True)
        return
    # 从数据库中查看积分兑换表
    result = await get_all_score_exchange()
    # 发送频道的信息
    result_str = "积分兑换列表:\n"
    # 使用embed输出一个表格形式的文字，显示积分兑换表的详情
    embed = discord.Embed(title="积分兑换列表", description=result_str, color=0x00ff00)
    for item in result:
        embed.add_field(name=f'ID: {item["id"]} 内容 {item["details"]}', value=f'所需积分: {item["score"]}')
    await interaction.response.send_message(result_str, ephemeral=True)


@client.tree.command(name='exchange')
@app_commands.describe(
    exchange_id='积分id',
)
@notify_admin
async def exchange(interaction: discord.Interaction, exchange_id: int):
    """用户发送兑换消息，扣除user_info的积分进行兑换"""
    if interaction.channel_id != SETTINGS.SHOP_CHANNEL_ID:
        await interaction.response.send_message('请到商店频道使用', ephemeral=True)
        return

    user = interaction.user

    # 查询该条积分的记录
    exchange_result = await get_score_exchange_details(exchange_id)
    # 查看用户的积分余额是否足够扣除积分
    exchange_detail = exchange_result['details']
    score = exchange_result['score']
    current_user_info = await get_user_info(user_id=user.id)
    # fixme 需要加临时锁防止兑换
    user_now_score = current_user_info['total_score']
    if user_now_score < score:
        # 不能兑换并发送消息
        await interaction.response.send_message(f'抱歉，你的积分不够兑换: {exchange_detail}', ephemeral=True)
    else:
        query = user_info.update().where(
            user_info.c.id == user.id,
        ).values(
            total_score=user_now_score - score
        )
        update_result = await database.execute(query)
        logger.info(f'{user.display_name} exchange {exchange_detail} score {score} success')
        await interaction.response.send_message(f'兑换 {exchange_detail} 成功', ephemeral=True)


@client.tree.command()
@notify_admin
async def gifts(interaction: discord.Interaction):
    """返回所有可供打赏的礼物列表"""
    if interaction.channel_id != SETTINGS.GIFT_CHANNEL_ID:
        await interaction.response.send_message('请到打赏频道使用该功能', ephemeral=True)
        return
    # gift_list = await get_all_gifts()
    gift_list_str = await format_emoji(gifts_text)
    result_str = f"**礼物列表**\n{gift_list_str}"
    # item_id = 1
    # for item in gift_list:
    #     details = gift_list[item]
    #     result_str += f"{item_id}.\t{details['name']}\t\t\t${details['price']}\n"
    #     item_id += 1
    await interaction.response.send_message(result_str, ephemeral=True)


@client.tree.command()
@app_commands.describe(
    成员='想看谁的呢',
)
@notify_admin
async def gift_receive_list(interaction: discord.Interaction, 成员: discord.User):
    """显示某位成员收到礼物赠送的列表，按时间从近到远排序"""

    if interaction.channel_id != SETTINGS.GIFT_CHANNEL_ID:
        await interaction.response.send_message('请到打赏频道使用该功能', ephemeral=True)
        return
    # 从数据库中查询该用户收到的礼物
    query = gift_record.select().where(
        gift_record.c.receiver_id == 成员.id
    ).order_by(
        gift_record.c.create_time.desc()
    )
    result = await database.fetch_all(query)
    result_str = f"**{成员.display_name}** 收到的礼物:\n"
    item_id = 1
    for item in result:
        gift_name = item['gift_name']
        gift_price = item['gift_price']
        gift_sender = item['sender_id']
        # 收到礼物的时间
        gift_time = item['create_time']
        result_str += f"{item_id}.\t{gift_name}\t${gift_price}\t{gift_sender}\t{gift_time}\n"
        item_id += 1

    await interaction.response.send_message(result_str, ephemeral=True)
    logger.info(f'{interaction.user.display_name} 获取了 {成员.display_name} 的礼物列表')


@client.tree.command()
@notify_admin
async def gift_receiver_list(interaction: discord.Interaction):
    """显示收到礼物赠送的成员列表，价格从高到低"""
    if interaction.channel_id != SETTINGS.GIFT_CHANNEL_ID:
        await interaction.response.send_message('请到打赏频道使用该功能', ephemeral=True)
        return
    # 从user_info里欸包中gift_score从高到低查询前十名
    query = user_info.select().order_by(
        user_info.c.gift_score.desc()
    ).limit(10)
    result = await database.fetch_all(query)
    result_str = "**心动榜**:\n"
    item_id = 1
    for item in result:
        gift_score = item['gift_score']
        if not gift_score or gift_score == 0:
            continue
        result_str += f"{item_id}.\t<@{item['id']}>\t\t\t{gift_score}\n"
        item_id += 1
    await interaction.response.send_message(result_str, ephemeral=True)


async def get_all_gifts():
    """获取所有礼物列表"""
    with open('data/gifts.json', 'r', encoding='utf-8') as f:
        gift_list = json.load(f)
    return gift_list


@client.tree.command(name='gift')
@app_commands.describe(
    礼物个数='礼物个数',
    礼物名字='礼物名字',
    送给='送给谁呢',
    是否匿名='是否匿名',
)
async def dashang(interaction: discord.Interaction, 礼物个数: int, 礼物名字: GiftName, 送给: discord.User,
                  是否匿名: AnonymousType):
    """打赏功能，告诉机器人给谁打赏礼物，机器人在聊天频道中公告"""
    if interaction.channel_id != SETTINGS.GIFT_CHANNEL_ID:
        await interaction.response.send_message('请到打赏频道使用该功能', ephemeral=True)
        return
    # if to.id == interaction.user.id:
    #     # 不能打赏给自己
    #     await interaction.response.send_message('不能打赏给自己', ephemeral=True)
    #     return
    # 不能打赏给机器人
    if 送给.bot:
        await interaction.response.send_message('不能打赏给机器人哦', ephemeral=True)
        return
    if not isinstance(礼物个数, int):
        # 礼物个数错误
        await interaction.response.send_message(f'礼物个数错误 {礼物个数}', ephemeral=True)
        return
    user = interaction.user
    gifts_list = await get_all_gifts()
    if 礼物名字 not in gifts_list:
        # 如果礼物不在列表，则发送消息告知
        await interaction.response.send_message(f'礼物 {礼物名字} 不在礼物列表中', ephemeral=True)
        return
    logger.info(f'{user.display_name} 打赏了 {送给.display_name} {礼物个数} 个 {礼物名字}')
    gift_image_url = gifts_list.get(礼物名字).get('image_url')
    gift_price = gifts_list.get(礼物名字).get('price')
    increase_price = round(gift_price * 礼物个数, 2)

    # 老板是否匿名
    from_mention = '匿名老板' if 是否匿名 == AnonymousType.我要匿名 else user.mention
    # 发送消息并且发送图片

    # special_gifts = ['咆哮']
    special_gifts = []
    if 礼物名字 in special_gifts:
        gift_response_template = gift_responses['special']
    else:
        gift_response_template = gift_responses['default']
    description = gift_response_template.format(
        from_user=from_mention,
        to_user=送给.mention,
        gift_name=礼物名字,
        gift_count=礼物个数,
        score=increase_price
    )
    description = await format_emoji(description)
    embed = discord.Embed(
        title=f'打赏通知！',
        description=description,
        color=discord.Color.green()
    )
    embed.set_image(url=gift_image_url)
    try:
        await interaction.response.send_message(
            f'已收到老板的打赏 {礼物个数} 个 {礼物名字} 到小可爱 {送给.display_name}',
            ephemeral=True
        )
        gift_channel = client.get_channel(SETTINGS.GIFT_CHANNEL_ID)
        await gift_channel.send(embed=embed)
        # 给接受打赏的人私发消息
        send_to_user_embed = discord.Embed(
            title=f'🎁礼物通知！',
            description=f""""♡ 叮咚 恭喜您收到老板 {user.display_name} 打赏的礼物：
✧  {礼物个数} 个 {礼物名字}
✧  每个价格为 $ {gift_price}
✧  总价为 $ {increase_price}
增加心动值 {increase_price} 点 
‼️ 请及时与在线客服确认老板余额和报单哦
‼️⌯'▾'⌯ 祝您生活旺旺 单子多多~ ଘ(੭ˊ꒳ˋ)੭✧
✧                                   ℍ𝕒𝕧𝕖 𝕒 𝕟𝕚𝕔𝕖 𝕕𝕒𝕪 ˙Ⱉ˙ฅ""",
            color=discord.Color.green()
        )
        send_to_user_embed.set_image(url=gift_image_url)
        await 送给.send(embed=send_to_user_embed)
        # broadcast_channel = client.get_channel(SETTINGS.BROADCAST_CHANNEL_ID)
        # await broadcast_channel.send(
        #     f'感谢老板 {from_mention} 打赏 {gift_name} X {gift_count} 礼物给陪陪 {to.mention}，'
        #     f'心动值增加 {increase_price}'
        # )
        # await broadcast_channel.send(gift_image_url)
    except Exception as e:
        logger.warning(f'发送消息失败 {e}')
    else:
        # 通知客服
        await client.get_channel(SETTINGS.GIFT_NOTIFY_CHANNEL_ID).send(
            f'[礼物通知] 老板 {user.mention} 礼物内容: {礼物个数}个{礼物名字} 总价: {increase_price} 心动值 {increase_price} 点 '
            f'送给 {送给.mention} {是否匿名.value}'
        )
        # 增加礼物赠送记录
        query = gift_record.insert().values(
            giver_id=user.id,
            receiver_id=送给.id,
            details=礼物名字,
            price=increase_price,
            create_time=datetime.now(pytz.timezone(SETTINGS.TIMEZONE))
        )
        await database.execute(query)
        logger.info(f'增加礼物赠送记录 {user.display_name} -> {送给.display_name} {礼物名字} {礼物个数}x{gift_price}')
        # 增加接收者的积分
        query = user_info.select().where(
            user_info.c.id == 送给.id
        )
        user_info_result = await database.fetch_one(query)
        if user_info_result:
            old_gift_score = user_info_result['gift_score']
            if not old_gift_score:
                old_gift_score = 0.0
            user_now_gift_score = round(old_gift_score + increase_price, 2)
            # 保留两位小数
            user_now_gift_score = round(user_now_gift_score, 2)
            query = user_info.update().where(
                user_info.c.id == 送给.id
            ).values(
                gift_score=user_now_gift_score
            )
            await database.execute(query)
            logger.info(f'增加礼物接收者的积分 {送给.display_name} {old_gift_score}->{user_now_gift_score}')
        else:
            # 新创建一条记录
            query = user_info.insert().values(
                id=送给.id,
                gift_score=increase_price
            )
            await database.execute(query)
            logger.info(f'新创建一条礼物记录 {送给.display_name} {increase_price}')


async def format_emoji(emoji_str):
    """使用正则将所有符合:{xx}:格式的字符串替换为emojis中的value"""
    global emojis
    if not emojis:
        emojis = {e.name: str(e) for e in client.emojis}
    # 使用正则将所有符合 :{xx}: 格式的字符串替换为 emojis 对应key的value
    pattern = re.compile(r':(\w+):')
    emoji_str = pattern.sub(lambda x: emojis.get(x.group(1), x.group()), emoji_str)
    return emoji_str


@client.tree.command()
async def help(interaction: discord.Interaction):
    """展示所有的command"""
    help_message = f"""所有的command如下：
/rand 摇骰子 
/roll 抽奖功能 
/gall 显示所有当前的抽奖 
/joined 显示member的加入时间 
/order 下单 
/gifts 返回所有可供打赏的礼物列表 
/gift 打赏功能，告诉机器人给谁打赏礼物，机器人在聊天频道中公告 
/help 展示所有的command 
/title 给某个小可爱冠名
/start 开始抽奖！
/end 结束抽奖咯！
"""
    # 只需要给出指固定文本
    # for command in client.tree.get_commands():
    #     按照command.name升序
    # help_message += f'/{command.name} {command.description}\n'
    # help_message = await format_emoji(help_message)
    await interaction.response.send_message(help_message, ephemeral=True)


# 欢迎用户加入频道
# @client.event
# async def on_member_join(member):
#     # 欢迎用户加入频道
#     welcome_channel = client.get_channel(SETTINGS.CHAT_CHANNEL_ID)
#     await welcome_channel.send(welcome_text.format(name=member.mention))
#     # 私信用户欢迎消息
#     await member.send(welcome_pp_text)
#     # # 给用户创建一条记录
#     # query = user_info.select().where(
#     #     user_info.c.id == member.id
#     # )
#     # user_info_result = await database


@client.tree.command(name='title')
@app_commands.describe(
    冠名="冠名类型:(半日冠、日冠、三日冠、五日冠)",
    给="要给哪位小可爱冠名呢",
    是否匿名='是否匿名'
)
@notify_admin
async def title(interaction: discord.Interaction, 冠名: NamedType, 给: discord.Member, 是否匿名: AnonymousType):
    """给某个小可爱冠名"""
    # 需要在打赏频道使用
    if interaction.channel.id != SETTINGS.GIFT_CHANNEL_ID:
        await interaction.response.send_message('请在打赏频道使用', ephemeral=True)
        return
    # 获取冠名的json
    with open('data/guanming.json', 'r', encoding='utf-8') as f:
        title_list = json.load(f)
    all_titles = title_list.keys()
    if 冠名 not in all_titles:
        await interaction.response.send_message(f'冠名类型 {冠名} 不在冠名列表中: {",".join(all_titles)}',
                                                ephemeral=True)
    # 需要采用特殊样式的类型
    special_titles = ['三日冠']

    # 输出带有图片的embed样式
    title_detail = title_list[冠名]
    image_url = title_detail['image_url']
    title_name = title_detail['name']
    title_price = title_detail['price']
    from_user_name = '匿名老板' if 是否匿名 == AnonymousType.我要匿名 else interaction.user.mention

    # 组装embed
    # if title in special_titles:
    #     response_template = rename_responses['special']
    # else:
    #     response_template = rename_responses['default']
    response_template = rename_responses.get(冠名,
                                             '(默认格式)感谢 {from_user_name} 给 {to_user_name} 冠名 {title_name}')
    description = response_template.format(
        from_user=from_user_name, to_user=给.mention,
        name=title_name, score=title_price
    )
    description = await format_emoji(description)
    embed = discord.Embed(
        title='冠名通知！',
        description=description,
        color=0xc991ae
    )
    embed.set_image(url=image_url)
    logger.info(f'{from_user_name} {冠名} {给.display_name}')

    # 广播
    broadcast_channel = client.get_channel(SETTINGS.GIFT_CHANNEL_ID)
    await broadcast_channel.send(embed=embed)

    embed.add_field(name='下单老板', value=interaction.user.mention, inline=True)
    await 给.send(embed=embed)
    await interaction.response.send_message(f'感谢老板给 {给.display_name} 冠名 {冠名}！ 发送播报！', ephemeral=True)


async def count_scores():
    """统计一次上周日0点到当前的所有对话消息，一条消息增加1点活跃度，按活跃度排序"""
    logger.info(f'start count scores')
    # 获取当前时间
    now = datetime.now(pytz.timezone(SETTINGS.TIMEZONE))
    # 获取上周日0点的时间
    last_week = now - timedelta(days=now.weekday() + 1)
    channel = client.get_channel(SETTINGS.CHAT_CHANNEL_ID)

    # 统计每个用户的消息数量
    user_message_count = {}
    async for message in channel.history(after=last_week):
        if message.author.bot:
            continue
        user_message_count[message.author.id] = user_message_count.get(message.author.id, 0) + 1
    # 按照消息数量排序
    user_message_count = sorted(user_message_count.items(), key=lambda x: x[1], reverse=True)
    # 获取前十名
    top_ten = user_message_count[:10]
    # 获取前十名的用户信息
    # 组装embed
    embed = discord.Embed(
        title='本周活跃度排行榜',
        # 格式化时间
        description=f'统计时间：{last_week.strftime("%Y-%m-%d %H:%M:%S")} - {now.strftime("%Y-%m-%d %H:%M:%S")}',
        color=0xc991ae
    )
    score_text = ''
    for i, (user_id, message_count) in enumerate(top_ten):
        user = await client.fetch_user(user_id)
        score_text += f'{i + 1}. {user.display_name} 发言数: {message_count}\n'
    embed.add_field(name='发言排行榜', value=score_text)
    # 广播
    broadcast_channel = client.get_channel(SETTINGS.ADMIN_CHANNEL_ID)
    logger.info(f'count scores done: {score_text}')
    await broadcast_channel.send(embed=embed)


@client.tree.command(name='start')
@app_commands.describe()
@notify_admin
async def start_game(interaction: discord.Interaction):
    """
    这是一个小游戏，可以抽取一些幸运用户
    """
    channel_id = interaction.channel_id
    if channel_id in game_start_channels:
        await interaction.response.send_message('抽奖已经开始了，请不要重复开始噢', ephemeral=True)
        return
    game_start_channels[channel_id] = {
        'start_time': datetime.now(),
        'participants': set()
    }
    start_embed = discord.Embed(
        title='抽奖开始了',
        description='大家快来参加吧！',
        color=0xc991ae
    )
    try:
        await interaction.response.send_message('指令收到，开始抽奖', ephemeral=True)
    except Exception as e:
        chat_channel = client.get_channel(channel_id)
        await chat_channel.send(embed=start_embed)
        logger.error(f'start game error: {e}')
    logger.info(f'start game in channel: {interaction.channel.name}')


@client.tree.command(name='end')
@app_commands.describe(抽取几位='抽取几位幸运用户')
@notify_admin
async def end_game(interaction: discord.Interaction, 抽取几位: int):
    """
    手动结束抽奖
    """
    # 1. /start 命令可以开始开始游戏，bot回复“开始游戏”。
    # 2. 其他用户可以在discord频道中回复任意字符串
    # 2. /end结束游戏，并统计从/start到/end命令中间的所有用户id，如果有重复的用户id需要去重，然后从中随机抽取一名用户，机器人回复：“幸运用户：@userid”

    channel_id = interaction.channel_id
    if channel_id not in game_start_channels:
        await interaction.response.send_message('抽奖还没有开始，请先开始抽奖噢', ephemeral=True)
        return
    game_users = game_start_channels[channel_id]['participants']
    game_start_time = game_start_channels[channel_id]['start_time']
    game_end_time = datetime.now()
    random_count = 抽取几位 if 抽取几位 <= len(game_users) else len(game_users)
    lucky_users = random.choices(list(game_users), k=random_count)
    chat_channel = client.get_channel(channel_id)
    lucky_users_str = ' '.join([f'<@{user}>' for user in lucky_users])
    lucky_embed = discord.Embed(
        title='抽奖结束了！',
        description=f'幸运鹅{lucky_users_str}.\n有奖竞猜的礼物被抱走啦！没抽中的宝贝不要灰心，没关系，人生处处是惊喜！｡･ﾟヾ(✦థ ｪ థ)ﾉ｡ﾟ･｡',
        color=0xc991ae,
    )
    logger.info(f'choice lucky guys and send message: {channel_id}')
    # lucky_embed.set_image(url='https://cdn.discordapp.com/attachments/921985463630299138/1106474302821380146/20.png')
    try:
        await chat_channel.send(embed=lucky_embed)
        logger.info(f'send lucky embed to chat channel: {chat_channel.name}')
    except discord.errors.HTTPException:
        logger.error(f'failed to send lucky embed to chat channel')
    try:
        await interaction.response.send_message(f'游戏结束了，共有{len(game_users)}人参加了游戏。', ephemeral=True)
        logger.info(f'send game end message to interaction channel: {chat_channel.name}')
    except discord.errors.HTTPException:
        logger.error(f'failed to send game end message to interaction channel')

    # 私信中奖人
    logger.info(f'notify lucky guys: {lucky_users}')
    for user in lucky_users:
        try:
            user_obj = await client.fetch_user(user)
            await user_obj.send(f'恭喜你在频道 {chat_channel.mention} 中抽中奖了，速速去看吧！')
            logger.info(f'send lucky message to user {user_obj.name}')
        except discord.errors.HTTPException:
            logger.error(f'failed to send lucky message to user {user}')

    # 礼物播报
    try:
        broadcast_channel = client.get_channel(SETTINGS.GAME_NOTIFY_CHANNEL_ID)
        await broadcast_channel.send(embed=lucky_embed)
        logger.info(f'send lucky embed to broadcast channel: {broadcast_channel.name}')
    except Exception as e:
        logger.warning(f'no broadcast_channel: {e}')

    used_time = game_end_time - game_start_time
    logger.info(f'end game, lucky guys in {len(game_users)} users: {lucky_users}, game time: {used_time} seconds')
    # 结束后清理
    del game_start_channels[channel_id]


@client.tree.command(name='xxlb')
@app_commands.describe(老板='感谢老板！')
@notify_admin
async def boss_id_image(interaction: discord.Interaction, 老板: discord.Member):
    """谢谢老板 """
    boss_id = 老板.id
    boss_info = order_custom_boss_info.get(str(boss_id))
    boss_image_url = boss_info.get('url')
    # u = 'https://media.discordapp.net/attachments/1040080636830040084/1073855722909077565/3.png'
    # boss_image_url = u
    if boss_image_url:
        embed = discord.Embed(title='谢谢老板！', color=0xc991ae)
        embed.set_image(url=boss_image_url)
        await interaction.response.send_message(embed=embed)


async def async_main():
    # logging日志的初始化
    discord_logger = logging.getLogger('discord')
    discord_logger.setLevel(logging.INFO)

    handler = RotatingFileHandler(
        filename='logs/discord.log',
        encoding='utf-8',
        maxBytes=32 * 1024 * 1024,  # 32 MiB
        backupCount=5,  # Rotate through 5 files
    )
    dt_fmt = '%Y-%m-%d %H:%M:%S'
    formatter = logging.Formatter('[{asctime}] [{levelname:<8}] {name}: {message}', dt_fmt, style='{')
    handler.setFormatter(formatter)
    discord_logger.addHandler(handler)

    async with engine.begin() as conn:
        # await conn.run_sync(metadata.drop_all)  # debug
        await conn.run_sync(metadata.create_all)

    await database.connect()
    # await engine.dispose()

    logger.info('start scheduler')


asyncio.run(async_main())
logger.info(f'start app 运行')

client.run(SETTINGS.TOKEN)
logger.info(f'stopped app 停止')
